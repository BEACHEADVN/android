ui_print "**********************************************************"
ui_print "*                                                                                                         *"
ui_print "*   TWEAK MIUI 13 MODULE FOR APOLLO PRO (FIRST BOOT) *"
ui_print "*                                                                                                         *"
ui_print "**********************************************************"


ui_print "!!! NHỚ THAY ĐỔI HÌNH NỀN TRƯỚC KHI KHỞI ĐỘNG LẠI."
ui_print " "
ui_print "!!! NHỚ THAY ĐỔI HÌNH NỀN TRƯỚC KHI KHỚI ĐỘNG LẠI."
ui_print " "
ui_print "!!! NHỚ THAY ĐỔI ÂM THANH TRƯỚC KHI KHỞI ĐỘNG LẠI."
ui_print " "
ui_print "!!! NHỚ THAY ĐỔI ÂM THANH TRƯỚC KHI KHỞI ĐỘNG LẠI."
ui_print " "
ui_print "!!! NHỚ THAY ĐỔI TẦN SỐ QUÉT MÀN HÌNH TRƯỚC KHI KHỞI ĐỘNG LẠI."
ui_print " "
ui_print "!!! NHỚ THAY ĐỔI TẦN SỐ QUÉT MÀN HÌNH TRƯỚC KHI KHỞI ĐỘNG LẠI."

ui_print " "
ui_print "   Bạn muốn thay đổi font?   "
ui_print " "
ui_print "   Hãy chọn:   "
ui_print " "
ui_print "   Vol+ = Có, Vol- = Không  "

if chooseport
then
	ui_print "•Thay đổi font   "
	mkdir -p "$MODPATH"/system/fonts
	fonts=$MODPATH/mod/font/fonts.list
	lines=`cat $fonts`
	for line in $lines
	do
		cp -rf "$MODPATH"/mod/font/Bauhaus.ttf "$MODPATH"/system/fonts/$line
	done
	rm -rf "$MODPATH"/mod/font
else
	ui_print "•Không thay đổi."
fi

ui_print "•Thay đổi bootanimation."
mkdir -p "$MODPATH"/system/media
cp -rf "$MODPATH"/mod/boot/bootanimation.zip "$MODPATH"/system/media
cp -rf "$MODPATH"/mod/boot/bootaudio.mp3 "$MODPATH"/system/media
rm -rf "$MODPATH"/mod/boot

ui_print " "
ui_print "   Bạn muốn tắt điều khiển nhiệt?   "
ui_print " "
ui_print "   Hãy chọn:   "
ui_print " "
ui_print "   Vol+ = Có, Vol- = Không  "

if chooseport
then
	ui_print "•Tắt điều khiển nhiệt."
	bins=$MODPATH/mod/thermal/bins.list
	lines=`cat $bins`
	for line in $lines
	do
		mktouch $MODPATH/system/vendor/bin/$line
	done
	rm -rf "$MODPATH"/mod/thermal/bins.list
	etcs=$MODPATH/mod/thermal/etcs.list
	lines=`cat $etcs`
	for line in $lines
	do
		mktouch $MODPATH/system/vendor/etc/$line
	done
	rm -rf "$MODPATH"/mod/thermal/etcs.list
	mktouch $MODPATH/system/vendor/etc/perf/thermalboost.conf
	rm -rf "$MODPATH"/mod/thermal
else
	ui_print "•Không thay đổi."
fi

rm -rf "$MODPATH"/mod