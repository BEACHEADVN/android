#!/system/bin/sh
# Edit by BEACHEAD for Apollo Pro

busybox killall -9 com.android.vending
killall -9 com.android.vending
am force-stop com.android.vending

#Zram
toybox swapoff /dev/block/zram0
echo 1 > /sys/block/zram0/reset
echo 0 > /sys/block/zram0/disksize
echo 1 > /sys/block/zram0/max_comp_streams
echo 0 > /sys/block/zram0/disksize
toybox mkswap /dev/block/zram0
toybox swapon /dev/block/zram0
echo 0 > /proc/sys/vm/drop_caches
echo 4096 > /sys/block/sda/queue/read_ahead_kb

#wait boot complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 1
done

# chạy lệnh
stop tcpdump
stop cnss_diag
stop logd
rm -rf /data/vendor/charge_logger/
rm -rf /data/vendor/wlan_logs/

# Tốc độ đọc tối ưu (UFS)
echo "0" >/sys/block/sda/queue/iostats
echo "0" >/sys/block/sdb/queue/iostats
echo "0" >/sys/block/sdc/queue/iostats
echo "0" >/sys/block/sdd/queue/iostats
echo "0" >/sys/block/sde/queue/iostats
echo "0" >/sys/block/sdf/queue/iostats

# chỉnh sửa binder
echo "0" >/sys/module/binder/parameters/debug_mask
echo "0" >/sys/module/binder_alloc/parameters/debug_mask
# Tắt lỗi kernel
echo "0" >/sys/module/msm_show_resume_irq/parameters/debug_mask
echo "N" >/sys/kernel/debug/debug_enabled
# Điều chỉnh không gian ảo
echo "0" >/proc/sys/vm/page-cluster
# Tắt những thứ không cần thiết
echo "0" >/sys/module/subsystem_restart/parameters/enable_ramdumps

# Tắt ghi nhật kí kernel
echo "off" >/proc/sys/kernel/printk_devkmsg
# 调整脏页写回策略时间
echo "3000" >/proc/sys/vm/dirty_expire_centisecs

# 禁用f2fs I/O数据收集统计
echo "0" >/sys/fs/f2fs/dm-5/iostat_enable
# 禁用调度统计
echo "0" >/proc/sys/kernel/sched_schedstats
# 调整虚拟内存统计间隔 (默认为1, 也就是1秒)
echo "20" >/proc/sys/vm/stat_interval

echo 0 > /proc/sys/net/ipv4/tcp_syncookies
echo 3 > /proc/sys/net/ipv4/tcp_fastopen
echo 1 > /proc/sys/net/ipv4/tcp_ecn
# tắt nhật ký Cpu
echo 0 > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv
echo 0 > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt
echo 0 > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd
echo 0 > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr
echo 0 > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem
# tắt nhật ký gpu
echo 0 > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_drv
echo 0 > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_ctxt
echo 0 > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_cmd
echo 0 > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_pwr
echo 0 > /sys/kernel/debug/kgsl/kgsl-3d0/log_level_mem

sleep 20

su -c "pm uninstall com.miui.miwallpaper.miweatherwallpaper"
su -c "pm uninstall com.miui.miwallpaper.earth"
su -c "pm uninstall com.miui.miwallpaper.snowmountain"
su -c "pm uninstall com.miui.miwallpaper.mars"
su -c "pm uninstall com.miui.miwallpaper.geometry"
su -c "pm uninstall com.miui.miwallpaper.saturn"

#Battery
chmod 777 /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
echo conservative > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
chmod 777 /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor
echo conservative > /sys/devices/system/cpu/cpu1/cpufreq/scaling_governor
chmod 777 /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
echo conservative > /sys/devices/system/cpu/cpu2/cpufreq/scaling_governor
chmod 777 /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor
echo conservative > /sys/devices/system/cpu/cpu3/cpufreq/scaling_governor
chmod 777 /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
echo conservative > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor
chmod 777 /sys/devices/system/cpu/cpu5/cpufreq/scaling_governor
echo conservative > /sys/devices/system/cpu/cpu5/cpufreq/scaling_governor
chmod 777 /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor
echo conservative > /sys/devices/system/cpu/cpu6/cpufreq/scaling_governor
chmod 777 /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
echo conservative > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor
chmod 777 /sys/class/kgsl/kgsl-3d0/min_clock_mhz
echo 305 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
chmod 777 /sys/class/kgsl/kgsl-3d0/devfreq/governor
echo powersave > /sys/class/kgsl/kgsl-3d0/devfreq/governor
chmod 777 /sys/class/kgsl/kgsl-3d0/default_pwrlevel
echo 5 > /sys/class/kgsl/kgsl-3d0/default_pwrlevel
chmod 777 /sys/block/sda/queue/scheduler
echo noop > /sys/block/sda/queue/scheduler

#Misc
echo 'N' > /sys/module/sync/parameters/fsync_enabled
echo '0' >/sys/kernel/dyn_fsync/Dyn_fsync_active 

#Fstrim 
fstrim /cache
fstrim /system
fstrim /data

#Davik, Cache
rm -rf /data/dalvik-cache/*

echo 0 > /proc/sys/vm/swappiness

#Zram
toybox swapoff /dev/block/zram0
echo 1 > /sys/block/zram0/reset
echo 0 > /sys/block/zram0/disksize
echo 1 > /sys/block/zram0/max_comp_streams
echo 0 > /sys/block/zram0/disksize
toybox mkswap /dev/block/zram0
toybox swapon /dev/block/zram0
echo 0 > /proc/sys/vm/drop_caches
echo 4096 > /sys/block/sda/queue/read_ahead_kb

sleep 10

busybox killall -9 com.android.vending
killall -9 com.android.vending
am force-stop com.android.vending

echo 3 > /proc/sys/vm/drop_caches
echo 0 > /proc/sys/vm/swappiness
s=`cat /proc/sys/vm/swappiness`
echo `date +"%r, %a, ngày %d, tháng %m, năm %Y"` >> /sdcard/Download/ext/temp/log
echo "•swappiness: $s" >> /storage/emulated/0/Download/ext/temp/log

sed -i 's/ PM,/ CH,/g; s/ AM,/ SA,/g; s/ Mon, / thứ Hai, /g; s/ Tue, / thứ Ba, /g; s/ Wed, / thứ Tư, /g; s/ Thur, / thứ Năm, /g; s/ Fri, / thứ Sáu, /g; s/ Sat, / thứ Bảy, /g; s/ Sun, / Chủ nhật, /g' /storage/emulated/0/Download/ext/temp/log

echo "$(tail -56 /storage/emulated/0/Download/ext/temp/log)" > /storage/emulated/0/Download/ext/temp/log