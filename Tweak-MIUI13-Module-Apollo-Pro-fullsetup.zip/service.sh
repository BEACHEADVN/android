#!/system/bin/sh
# Edit by BEACHEAD for Apollo Pro

#wait boot complete
while [ "$(getprop sys.boot_completed)" != "1" ]
do
	sleep 1
done

sleep 5

pm disable com.google.android.documentsui
pm disable com.android.fileexplorer
pm disable com.VCB
pm disable org.adaway
pm disable com.android.cellbroadcastreceiver.module
pm disable com.android.cellbroadcastreceiver.overlay.common
pm disable com.xiaomi.bluetooth.overlay
pm disable com.android.cts.ctsshim
pm disable com.android.cts.priv.ctsshim
pm disable android.aosp.overlay
pm disable android.miui.overlay
pm disable android.overlay.common
pm disable android.overlay.target
pm disable com.android.bluetooth.overlay.common
pm disable com.google.android.documentsui
pm disable com.android.fileexplorer
pm disable com.android.hotspot2.osulogin
pm disable com.google.android.cellbroadcastservice.overlay.miui
pm disable com.google.android.cellbroadcastreceiver.overlay.miui
pm disable com.xiaomi.bluetooth
pm disable com.miui.powerkeeper
pm disable com.azzphucfree.dev
pm disable com.mihoyo.hoyolab
pm disable com.shopee.vn
pm disable com.android.vpndialogs

sleep 180

path=`su -c "find /data/app -type d -name 'com.google.ar.core*'"`

if [ -z "$path" ]
then
      echo `date +"%r, %a, ngày %d, tháng %m, năm %Y"` >> /sdcard/Download/ext/temp/log
      echo "•Google Play for AR không bị cài đặt." >> /storage/emulated/0/Download/ext/temp/log
else
      su -c "pm uninstall com.google.ar.core"
      echo `date +"%r, %a, ngày %d, tháng %m, năm %Y"` >> /sdcard/Download/ext/temp/log
      echo "•Google Play for AR đã gỡ cài đặt." >> /storage/emulated/0/Download/ext/temp/log
fi

sed -i 's/ PM,/ CH,/g; s/ AM,/ SA,/g; s/ Mon, / thứ Hai, /g; s/ Tue, / thứ Ba, /g; s/ Wed, / thứ Tư, /g; s/ Thur, / thứ Năm, /g; s/ Fri, / thứ Sáu, /g; s/ Sat, / thứ Bảy, /g; s/ Sun, / Chủ nhật, /g' /storage/emulated/0/Download/ext/temp/log

echo "$(tail -56 /storage/emulated/0/Download/ext/temp/log)" > /storage/emulated/0/Download/ext/temp/log