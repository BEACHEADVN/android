##########################################################################################
#
# MMT Extended Config Script
#
##########################################################################################

##########################################################################################
# Config Flags
##########################################################################################

# Uncomment and change 'MINAPI' and 'MAXAPI' to the minimum and maximum android version for your mod
# Uncomment DYNLIB if you want libs installed to vendor for oreo+ and system for anything older
# Uncomment DEBUG if you want full debug logs (saved to /sdcard)
#MINAPI=21
#MAXAPI=25
#DYNLIB=true
#DEBUG=true

##########################################################################################
# Replace list
##########################################################################################

# List all directories you want to directly replace in the system
# Check the documentations for more info why you would need this

# Construct your list in the following format
# This is an example
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# Construct your own list here
REPLACE="
/system/app/CatchLog
/system/app/EasterEgg
/system/app/GooglePrintRecommendationService
/system/app/KeyChain
/system/app/MiuixEditor
/system/app/ModemTestBox
/system/app/PlatformCaptivePortalLogin
/system/app/PrintSpooler
/system/app/Stk
/system/app/Traceur
/system/app/WallpaperBackup
/system/app/com.miui.qr
/system/priv-app/Backup
/system/priv-app/BackupRestoreConfirmation
/system/priv-app/BlockedNumberProvider
/system/priv-app/BuiltInPrintService
/system/priv-app/CalendarProvider
/system/priv-app/CallLogBackup
/system/priv-app/CellBroadcastServiceModulePlatform
/system/priv-app/DynamicSystemInstallationService
/system/priv-app/LiveWallpapersPicker
/system/priv-app/LocalTransport
/system/priv-app/ManagedProvisioning
/system/priv-app/MusicFX
/system/priv-app/ONS
/system/priv-app/Tag
/system/priv-app/UserDictionaryProvider
/system/product/app/Calculator
/system/product/app/Cit
/system/product/app/CloudService
/system/product/app/Email
/system/product/app/GoogleCalendarSyncAdapter
/system/product/app/GoogleContactsSyncAdapter
/system/product/app/GoogleLocationHistory
/system/product/app/Health
/system/product/app/IFAAService
/system/product/app/Joyose
/system/product/app/LatinImeGoogle
/system/product/app/MiCloudSync
/system/product/app/MiConnectService
/system/product/app/MiDrive
/system/product/app/MiGalleryLockscreen
/system/product/app/MiLinkService
/system/product/app/MipayService
/system/product/app/MiuiBugReport
/system/product/app/MiuiCompass
/system/product/app/MiuiFrequentPhrase
/system/product/app/MiuiInputSettings
/system/product/app/MiuiReporter
/system/product/app/MiuiScreenRecorder
/system/product/app/MiuiVideoGlobal
/system/product/app/Notes
/system/product/app/PaymentService
/system/product/app/RideModeAudio
/system/product/app/SpeechServicesByGoogle
/system/product/app/TouchAssistant
/system/product/app/Updater
/system/product/app/XiaomiSimActivateService
/system/product/app/com.xiaomi.ugd
/system/product/app/wps-lite
/system/product/priv-app/AndroidAutoStub
/system/product/priv-app/Calendar
/system/product/priv-app/CleanMaster
/system/product/priv-app/CloudBackup
/system/product/priv-app/DownloadProviderUi
/system/product/priv-app/GoogleOneTimeInitializer
/system/product/priv-app/GooglePartnerSetup
/system/product/priv-app/GoogleRestore
/system/product/priv-app/MiBrowserGlobal
/system/product/priv-app/MiMover
/system/product/priv-app/MiService
/system/product/priv-app/MiShare
/system/product/priv-app/Mirror
/system/product/priv-app/MiuiAod
/system/product/priv-app/MiuiExtraPhoto
/system/product/priv-app/MiuiGallery
/system/product/priv-app/MiuiScanner
/system/product/priv-app/Music
/system/product/priv-app/PersonalAssistant
/system/product/priv-app/SoundRecorder
/system/product/priv-app/Velvet
/system/product/priv-app/Weather
/system/system_ext/app/MiuiContentCatcher
/system/system_ext/app/NQNfcNci
/system/system_ext/priv-app/CellBroadcastAppPlatform
/system/system_ext/priv-app/EmergencyInfo
/system/system_ext/priv-app/GoogleFeedback
/system/system_ext/priv-app/Polaris
/system/system_ext/priv-app/QualcommVoiceActivation
/system/system_ext/priv-app/SetupWizard
/system/system_ext/priv-app/WallpaperCropper
/system/vendor/app/com.qualcomm.qti.gpudrivers.kalama.api33
"

##########################################################################################
# Permissions
##########################################################################################

set_permissions() {
  : # Remove this if adding to this function

  # Note that all files/folders in magisk module directory have the $MODPATH prefix - keep this prefix on all of your files/folders
  # Some examples:
  
  # For directories (includes files in them):
  # set_perm_recursive  <dirname>                <owner> <group> <dirpermission> <filepermission> <contexts> (default: u:object_r:system_file:s0)
  
  # set_perm_recursive $MODPATH/system/lib 0 0 0755 0644
  # set_perm_recursive $MODPATH/system/vendor/lib/soundfx 0 0 0755 0644

  # For files (not in directories taken care of above)
  # set_perm  <filename>                         <owner> <group> <permission> <contexts> (default: u:object_r:system_file:s0)
  
  # set_perm $MODPATH/system/lib/libart.so 0 0 0644
  # set_perm /data/local/tmp/file.txt 0 0 644
}

##########################################################################################
# MMT Extended Logic - Don't modify anything after this
##########################################################################################

SKIPUNZIP=1
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh
