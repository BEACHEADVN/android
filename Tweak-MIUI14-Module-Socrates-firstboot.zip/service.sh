#!/system/bin/sh
# Edit by BEACHEAD for Socrates

busybox killall -9 com.android.vending
killall -9 com.android.vending
am force-stop com.android.vending

#wait boot complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do
	sleep 1
done

sleep 10

su -c "pm uninstall com.miui.miwallpaper.miweatherwallpaper"
su -c "pm uninstall com.miui.miwallpaper.earth"
su -c "pm uninstall com.miui.miwallpaper.snowmountain"
su -c "pm uninstall com.miui.miwallpaper.mars"
su -c "pm uninstall com.miui.miwallpaper.geometry"
su -c "pm uninstall com.miui.miwallpaper.saturn"

#GPU
chmod 777 /sys/class/kgsl/kgsl-3d0/min_clock_mhz
echo 220 > /sys/class/kgsl/kgsl-3d0/min_clock_mhz
chmod 777 /sys/class/kgsl/kgsl-3d0/max_clock_mhz
echo 220 > /sys/class/kgsl/kgsl-3d0/max_clock_mhz
chmod 777 /sys/class/kgsl/kgsl-3d0/default_pwrlevel
echo 7 > /sys/class/kgsl/kgsl-3d0/default_pwrlevel

#Zram
toybox swapoff /dev/block/zram0
echo 1 > /sys/block/zram0/reset
echo 3072MB > /sys/block/zram0/disksize
echo 1 > /sys/block/zram0/max_comp_streams
echo 0 > /sys/block/zram0/disksize
toybox mkswap /dev/block/zram0
toybox swapon /dev/block/zram0
echo 4096 > /sys/block/sda/queue/read_ahead_kb
echo 3 > /proc/sys/vm/drop_caches
echo 50 > /proc/sys/vm/swappiness


#Davik, Cache
rm -rf /data/dalvik-cache/*

sleep 10

busybox killall -9 com.android.vending
killall -9 com.android.vending
am force-stop com.android.vending

s=`cat /proc/sys/vm/swappiness`
echo `date +"%r, %a, ngày %d, tháng %m, năm %Y"` >> /sdcard/Download/ext/temp/log
echo "•swappiness: $s" >> /storage/emulated/0/Download/ext/temp/log
s=`cat /sys/class/kgsl/kgsl-3d0/max_clock_mhz`
echo "•GPU Max Clock: $s MHz" >> /storage/emulated/0/Download/ext/temp/log

sed -i 's/ PM,/ CH,/g; s/ AM,/ SA,/g; s/ Mon, / thứ Hai, /g; s/ Tue, / thứ Ba, /g; s/ Wed, / thứ Tư, /g; s/ Thur, / thứ Năm, /g; s/ Fri, / thứ Sáu, /g; s/ Sat, / thứ Bảy, /g; s/ Sun, / Chủ nhật, /g' /storage/emulated/0/Download/ext/temp/log

echo "$(tail -56 /storage/emulated/0/Download/ext/temp/log)" > /storage/emulated/0/Download/ext/temp/log