ui_print "**********************************************************"
ui_print "*                                                                                                        *"
ui_print "*   TWEAK MIUI 14 MODULE FOR SOCRATES (FULL SETUP)  *"
ui_print "*                                                                                                        *"
ui_print "**********************************************************"

ui_print " "
ui_print "   Ban muon loai bo Bluetooth?   "
ui_print " "
ui_print "   Hay chon:   "
ui_print " "
ui_print "   Vol+ = Co, Vol- = Khong  "

if chooseport; then
   ui_print "   Loai bo Bluetooth   "
   mktouch $MODPATH/system/app/Bluetooth/.replace
   mktouch $MODPATH/system/app/BluetoothMidiService/.replace
   mktouch $MODPATH/system/app/MiuiBluetooth/.replace
else
   ui_print "   Không thay đổi.   "
fi

ui_print " "
ui_print "   Ban muon loai bo ung dung Theme?   "
ui_print " "
ui_print "   Hay chon:   "
ui_print " "
ui_print "   Vol+ = Co, Vol- = Khong  "

if chooseport; then
   ui_print "   Loai bo ung dung Theme   "
   mktouch $MODPATH/system/app/ThemeManager/.replace
   mktouch $MODPATH/system/app/ThemeModule/.replace
else
   ui_print "   Không thay đổi.   "
fi

mktouch $MODPATH/system/apex/com.android.apex.cts.shim.apex